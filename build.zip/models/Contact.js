// contactModel.js

const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        // Add email validation if needed
    },
    phone: {
        type: String,
        required: true,
        // You might want to add validation for phone numbers
    },
    message: {
        type: String,
        required: true,
    },
});

const Contact = mongoose.model('Contact', contactSchema);

module.exports = Contact;
